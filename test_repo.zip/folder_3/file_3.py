from folder_2.file_3 import something

def func():
    print('hello')
