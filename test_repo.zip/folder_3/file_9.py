from folder_2.file_9 import something

def func():
    print('hello')
