from folder_2.file_2 import something

def func():
    print('hello')
