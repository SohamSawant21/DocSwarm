from folder_2.file_6 import something

def func():
    print('hello')
