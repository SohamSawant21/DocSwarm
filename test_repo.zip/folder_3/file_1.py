from folder_2.file_1 import something

def func():
    print('hello')
