from folder_2.file_0 import something

def func():
    print('hello')
