from folder_2.file_7 import something

def func():
    print('hello')
