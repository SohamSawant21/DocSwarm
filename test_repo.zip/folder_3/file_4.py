from folder_2.file_4 import something

def func():
    print('hello')
