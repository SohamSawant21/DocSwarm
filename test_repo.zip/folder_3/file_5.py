from folder_2.file_5 import something

def func():
    print('hello')
