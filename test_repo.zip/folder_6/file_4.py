from folder_5.file_4 import something

def func():
    print('hello')
