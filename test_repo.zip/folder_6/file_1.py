from folder_5.file_1 import something

def func():
    print('hello')
