from folder_5.file_7 import something

def func():
    print('hello')
