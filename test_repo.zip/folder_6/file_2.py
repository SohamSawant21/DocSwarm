from folder_5.file_2 import something

def func():
    print('hello')
