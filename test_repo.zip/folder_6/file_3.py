from folder_5.file_3 import something

def func():
    print('hello')
