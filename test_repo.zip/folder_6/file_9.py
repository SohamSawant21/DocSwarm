from folder_5.file_9 import something

def func():
    print('hello')
