from folder_5.file_0 import something

def func():
    print('hello')
