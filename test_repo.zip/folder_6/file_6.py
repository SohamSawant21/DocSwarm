from folder_5.file_6 import something

def func():
    print('hello')
