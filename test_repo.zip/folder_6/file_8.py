from folder_5.file_8 import something

def func():
    print('hello')
