from folder_4.file_5 import something

def func():
    print('hello')
