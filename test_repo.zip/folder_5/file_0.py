from folder_4.file_0 import something

def func():
    print('hello')
