from folder_4.file_4 import something

def func():
    print('hello')
