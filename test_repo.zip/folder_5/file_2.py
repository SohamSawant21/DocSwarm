from folder_4.file_2 import something

def func():
    print('hello')
