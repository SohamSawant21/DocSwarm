from folder_4.file_8 import something

def func():
    print('hello')
