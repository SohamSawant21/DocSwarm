from folder_4.file_6 import something

def func():
    print('hello')
