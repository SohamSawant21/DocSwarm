from folder_4.file_3 import something

def func():
    print('hello')
