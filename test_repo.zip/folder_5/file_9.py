from folder_4.file_9 import something

def func():
    print('hello')
