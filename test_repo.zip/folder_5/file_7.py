from folder_4.file_7 import something

def func():
    print('hello')
