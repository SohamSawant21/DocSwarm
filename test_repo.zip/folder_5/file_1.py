from folder_4.file_1 import something

def func():
    print('hello')
