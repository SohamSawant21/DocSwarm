from folder_0.file_3 import something

def func():
    print('hello')
