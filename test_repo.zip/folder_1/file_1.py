from folder_0.file_1 import something

def func():
    print('hello')
