from folder_0.file_4 import something

def func():
    print('hello')
