from folder_0.file_6 import something

def func():
    print('hello')
