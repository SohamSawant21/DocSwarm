from folder_0.file_2 import something

def func():
    print('hello')
