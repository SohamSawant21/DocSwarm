from folder_0.file_5 import something

def func():
    print('hello')
