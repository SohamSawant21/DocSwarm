from folder_0.file_0 import something

def func():
    print('hello')
