from folder_0.file_9 import something

def func():
    print('hello')
