from folder_0.file_7 import something

def func():
    print('hello')
