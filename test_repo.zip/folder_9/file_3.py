from folder_8.file_3 import something

def func():
    print('hello')
