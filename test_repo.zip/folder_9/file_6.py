from folder_8.file_6 import something

def func():
    print('hello')
