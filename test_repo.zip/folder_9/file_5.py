from folder_8.file_5 import something

def func():
    print('hello')
