from folder_8.file_9 import something

def func():
    print('hello')
