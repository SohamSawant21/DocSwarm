from folder_8.file_4 import something

def func():
    print('hello')
