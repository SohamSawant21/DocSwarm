from folder_8.file_8 import something

def func():
    print('hello')
