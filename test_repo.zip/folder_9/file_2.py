from folder_8.file_2 import something

def func():
    print('hello')
