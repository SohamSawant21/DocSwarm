from folder_8.file_0 import something

def func():
    print('hello')
