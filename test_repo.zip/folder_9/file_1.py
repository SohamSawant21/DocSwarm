from folder_8.file_1 import something

def func():
    print('hello')
