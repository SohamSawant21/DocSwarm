from folder_8.file_7 import something

def func():
    print('hello')
