from folder_1.file_7 import something

def func():
    print('hello')
