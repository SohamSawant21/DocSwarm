from folder_1.file_1 import something

def func():
    print('hello')
