from folder_1.file_9 import something

def func():
    print('hello')
