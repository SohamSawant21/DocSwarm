from folder_1.file_3 import something

def func():
    print('hello')
