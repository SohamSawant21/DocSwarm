from folder_1.file_8 import something

def func():
    print('hello')
