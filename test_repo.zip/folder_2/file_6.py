from folder_1.file_6 import something

def func():
    print('hello')
