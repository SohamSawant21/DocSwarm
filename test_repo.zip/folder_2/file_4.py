from folder_1.file_4 import something

def func():
    print('hello')
