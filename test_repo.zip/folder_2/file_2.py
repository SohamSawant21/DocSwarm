from folder_1.file_2 import something

def func():
    print('hello')
