from folder_1.file_0 import something

def func():
    print('hello')
