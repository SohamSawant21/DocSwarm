import folder_0.file_0
print('hello world')