from folder_6.file_1 import something

def func():
    print('hello')
