from folder_6.file_8 import something

def func():
    print('hello')
