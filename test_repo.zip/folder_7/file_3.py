from folder_6.file_3 import something

def func():
    print('hello')
