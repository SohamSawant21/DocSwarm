from folder_6.file_5 import something

def func():
    print('hello')
