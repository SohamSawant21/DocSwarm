from folder_6.file_6 import something

def func():
    print('hello')
