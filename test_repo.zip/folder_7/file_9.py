from folder_6.file_9 import something

def func():
    print('hello')
