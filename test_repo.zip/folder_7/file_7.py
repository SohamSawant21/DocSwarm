from folder_6.file_7 import something

def func():
    print('hello')
