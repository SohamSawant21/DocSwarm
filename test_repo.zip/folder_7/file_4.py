from folder_6.file_4 import something

def func():
    print('hello')
