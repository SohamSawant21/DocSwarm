from folder_6.file_0 import something

def func():
    print('hello')
