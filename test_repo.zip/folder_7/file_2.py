from folder_6.file_2 import something

def func():
    print('hello')
