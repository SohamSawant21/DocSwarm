from folder_7.file_0 import something

def func():
    print('hello')
