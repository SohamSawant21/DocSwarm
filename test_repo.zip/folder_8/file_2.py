from folder_7.file_2 import something

def func():
    print('hello')
