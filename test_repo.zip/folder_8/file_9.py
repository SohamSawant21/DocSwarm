from folder_7.file_9 import something

def func():
    print('hello')
