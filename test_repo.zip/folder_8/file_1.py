from folder_7.file_1 import something

def func():
    print('hello')
