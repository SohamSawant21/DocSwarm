from folder_7.file_3 import something

def func():
    print('hello')
