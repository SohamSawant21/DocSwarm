from folder_7.file_4 import something

def func():
    print('hello')
