from folder_7.file_7 import something

def func():
    print('hello')
