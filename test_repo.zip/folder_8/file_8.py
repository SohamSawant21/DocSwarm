from folder_7.file_8 import something

def func():
    print('hello')
