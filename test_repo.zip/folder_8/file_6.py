from folder_7.file_6 import something

def func():
    print('hello')
