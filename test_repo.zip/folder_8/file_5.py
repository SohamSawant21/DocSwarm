from folder_7.file_5 import something

def func():
    print('hello')
