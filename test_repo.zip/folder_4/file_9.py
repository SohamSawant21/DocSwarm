from folder_3.file_9 import something

def func():
    print('hello')
