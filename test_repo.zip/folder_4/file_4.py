from folder_3.file_4 import something

def func():
    print('hello')
