from folder_3.file_3 import something

def func():
    print('hello')
