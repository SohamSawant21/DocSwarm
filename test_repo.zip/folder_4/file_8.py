from folder_3.file_8 import something

def func():
    print('hello')
