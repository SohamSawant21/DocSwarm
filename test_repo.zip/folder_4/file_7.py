from folder_3.file_7 import something

def func():
    print('hello')
