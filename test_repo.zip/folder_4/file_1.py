from folder_3.file_1 import something

def func():
    print('hello')
