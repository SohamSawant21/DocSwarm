from folder_3.file_2 import something

def func():
    print('hello')
