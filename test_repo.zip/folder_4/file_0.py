from folder_3.file_0 import something

def func():
    print('hello')
