from folder_3.file_6 import something

def func():
    print('hello')
