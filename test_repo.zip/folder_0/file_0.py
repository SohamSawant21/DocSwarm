

def func():
    print('hello')
